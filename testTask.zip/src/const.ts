const timeFormat = "HH:mm:ss";

export const CONST = {
  timeFormat,
};
